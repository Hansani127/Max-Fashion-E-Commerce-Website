<?php
include 'db.php';

if (!isset($_GET['product_id'])) {
    die("No product specified.");
}

$productId = $_GET['product_id'];

// First fetch image file names to delete from server
$stmt = $conn->prepare("SELECT image1, image2, image3, image4 FROM products WHERE product_id = ?");
$stmt->bind_param("s", $productId);
$stmt->execute();
$result = $stmt->get_result();

if ($product = $result->fetch_assoc()) {
    $images = [
        $product['image1'],
        $product['image2'],
        $product['image3'],
        $product['image4']
    ];

    $uploadDir = "/Applications/XAMPP/xamppfiles/htdocs/MaxFashionConnect/uploads/";

    // Delete each image file if exists
    foreach ($images as $img) {
        if ($img && file_exists($uploadDir . $img)) {
            unlink($uploadDir . $img);
        }
    }
} else {
    $stmt->close();
    $conn->close();
    die("Product not found.");
}

$stmt->close();

// Now delete product record from DB
$stmtDel = $conn->prepare("DELETE FROM products WHERE product_id = ?");
$stmtDel->bind_param("s", $productId);

if ($stmtDel->execute()) {
    $stmtDel->close();
    $conn->close();
    header("Location: adminS.php?deleted=1");
    exit();
} else {
    echo "Error deleting product: " . $stmtDel->error;
}

$stmtDel->close();
$conn->close();
?>
