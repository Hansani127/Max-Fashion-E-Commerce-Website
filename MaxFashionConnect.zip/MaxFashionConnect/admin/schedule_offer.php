<?php
include 'db.php'; // assumes this file connects to the $conn

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $offerName = $data['offerName'] ?? '';
    $startDate = $data['startDate'] ?? '';
    $endDate = $data['endDate'] ?? '';
    $products = $data['products'] ?? [];

    if (empty($offerName) || empty($startDate) || empty($endDate) || empty($products)) {
        $response['message'] = "All fields are required.";
        echo json_encode($response);
        exit;
    }

    $conn->begin_transaction();

    try {
        // Insert into offers table
        $stmt = $conn->prepare("INSERT INTO offers (offer_name, start_date, end_date) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $offerName, $startDate, $endDate);
        $stmt->execute();
        $offerId = $stmt->insert_id;
        $stmt->close();

        // Insert each product into offer_products
        $stmt = $conn->prepare("INSERT INTO offer_products (offer_id, product_id, old_price, discount_percent, new_price) VALUES (?, ?, ?, ?, ?)");

        foreach ($products as $p) {
            $pid = $p['product_id'];
            $oldPrice = $p['old_price'];
            $discount = $p['discount_percent'];
            $newPrice = $p['new_price'];

            $stmt->bind_param("isddd", $offerId, $pid, $oldPrice, $discount, $newPrice);
            $stmt->execute();
        }

        $stmt->close();
        $conn->commit();

        $response['success'] = true;
        $response['message'] = "Offer scheduled successfully.";

    } catch (Exception $e) {
        $conn->rollback();
        $response['message'] = "Error: " . $e->getMessage();
    }

    $conn->close();
} else {
    $response['message'] = "Invalid request method.";
}

echo json_encode($response);
?>
