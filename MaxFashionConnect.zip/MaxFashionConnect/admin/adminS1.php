
<?php
// Enable error reporting (optional but helpful during development)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session (if you're using login/auth)
session_start();

// Include DB connection
include 'db.php';

// Optional: Check if admin is logged in (if using sessions)
// if (!isset($_SESSION['admin_logged_in'])) {
//   header("Location: login.php");
//   exit();
// }
?>



<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8" />
  <title>Max Fashion Admin Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&display=swap"rel="stylesheet"/>
  <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"/>
  <link rel="stylesheet" href="css/admin.css">

  <style>


#scheduleOffers input,
#scheduleOffers button,
#scheduleOffers label {
  display: block;
  margin: 8px 0;
  width: 100%;
  padding: 8px;
  font-family: 'Outfit', sans-serif;
}

#discountedList {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

#discountedList th,
#discountedList td {
  border: 1px solid #ddd;
  padding: 10px;
  text-align: center;
}

#discountedList th {
  background-color: #f4f4f4;
}

#discountedList button {
  background-color: #d9534f;
  color: white;
  border: none;
  padding: 6px 10px;
  cursor: pointer;
  border-radius: 4px;
}

#discountedList button:hover {
  background-color: #c9302c;
}






  </style>

</head>
<body>

  <aside class="sidebar" aria-label="Admin sidebar navigation">
    <div class="toggle-btn" role="button" tabindex="0" aria-label="Toggle sidebar menu" title="Toggle sidebar">
      <i class="bi bi-list"></i>
    </div>
    <nav role="navigation" aria-label="Admin navigation menu">
      <button class="nav-link active" data-target="dashboard" aria-current="page"><i class="bi bi-speedometer2"></i><span>Dashboard</span></button>
      <button class="nav-link" data-target="manageProducts"><i class="bi bi-box-seam"></i><span>Products</span></button>
      <button class="nav-link" data-target="manageOrders"><i class="bi bi-card-checklist"></i><span>Orders</span></button>
      <button class="nav-link" data-target="manageNotifications"><i class="bi bi-bell"></i><span>Notifications</span></button>
      <button class="nav-link" data-target="manageEmployees"><i class="bi bi-people"></i><span>Employees</span></button>
      <button class="nav-link" data-target="scheduleOffers"><i class="bi bi-calendar-event"></i><span>Offers</span></button>
      <button class="nav-link" data-target="customerInquiries"><i class="bi bi-chat-dots"></i><span>Inquiries</span></button>
    </nav>
  </aside>

<header>
  <div class="logo" aria-label="Max Fashion Logo">
    <img src="assets/logooo.jpeg" alt="Max Fashion Logo" />
  </div>

  <div style="display: flex; align-items: center; flex-grow: 1;">
    <div class="search-bar">
      <input type="text" placeholder="Search orders, products, inquiries..." aria-label="Search orders, products, inquiries" />
      <i class="bi bi-search"></i>
    </div>

    <div class="header-icons" role="region" aria-label="User actions" style="margin-left: auto; display: flex; align-items: center; gap: 1.2rem;">
      <!-- Notification icon first -->
      <div class="notifications" role="button" tabindex="0" aria-label="View notifications">
        <i class="bi bi-bell"></i>
        <span class="badge" id="notifBadge">3</span>
      </div>

      <!-- Then the profile icon -->
      <div class="admin-profile" role="button" tabindex="0" aria-haspopup="true" aria-expanded="false" aria-label="Admin profile menu">
        <img src="https://i.pravatar.cc/150?img=3" alt="Admin Profile Picture" />
        <div class="profile-dropdown" id="profileDropdown" role="menu" aria-hidden="true">
          <a href="#" role="menuitem" id="profileView">View Profile</a>
          <a href="#" role="menuitem" id="profileSettings">Settings</a>
          <button type="button" role="menuitem" id="logoutBtn">Logout</button>
        </div>
      </div>
    </div>
  </div>
</header>



  <main>
    <!-- Dashboard overview cards -->
    <section id="dashboard" class="admin-panel active" tabindex="0" aria-label="Dashboard Overview">
      <h1>Dashboard Overview</h1>
      <div class="dashboard-overview">
        <div class="overview-card" aria-label="Total Products">
          <h2>120</h2>
          <p>Products</p>
        </div>
        <div class="overview-card" aria-label="Pending Orders">
          <h2>35</h2>
          <p>Pending Orders</p>
        </div>
        <div class="overview-card" aria-label="New Customer Inquiries">
          <h2>7</h2>
          <p>New Inquiries</p>
        </div>
        <div class="overview-card" aria-label="Scheduled Offers">
          <h2>3</h2>
          <p>Scheduled Offers</p>
        </div>
        <div class="overview-card" aria-label="Employees">
          <h2>15</h2>
          <p>Employees</p>
        </div>
      </div>
    </section>


     <!-- Manage Product section -->

  <section id="manageProducts" class="admin-panel">
  <h1>Manage Products</h1>
  <p class="lead">Add, edit, or remove products from your store.</p>

  <div class="tab-buttons">
    <button class="tab-btn active" onclick="showTab('addProductTab')">Add New Product</button>
    <button class="tab-btn" onclick="showTab('updateProductTab')">Update or Delete Product</button>
  </div>

  <div id="addProductTab" class="tab-content active">
    <h2>Add New Product</h2>
    <form id="addProductForm" action="add_product_backend.php" method="POST" enctype="multipart/form-data">
      <input type="text" name="product_id" placeholder="Product ID" required>
      <input type="text" name="name" placeholder="Product Name" required>
      <input type="number" name="price" placeholder="Price (Rs)" required>
      <textarea name="description" placeholder="Product Description" required></textarea>

      <label>Available Sizes:</label>
      <select name="sizes[]" multiple required>
        <option>S</option>
        <option>M</option>
        <option>L</option>
        <option>XL</option>
        <option>XXL</option>
      </select>

      <label><input type="checkbox" name="is_new"> Mark as New Arrival</label>

      <label>Upload Product Images (4 or more):</label>
      <input type="file" name="images[]" multiple accept="image/*" onchange="previewAddImages(event)" required>
      <div id="addImagePreview" class="image-preview"></div>

      <button type="submit">Add Product</button>
    </form>
  </div>

  <div id="updateProductTab" class="tab-content">
    <h2>Update or Delete Product</h2>
    <form id="fetchProductForm">
      <input type="text" id="updateProductId" name="product_id" placeholder="Enter Product ID" required>
      <button class="fetch-btn" type="submit">Fetch</button>
    </form>

    <form id="updateProductForm" action="update_product_backend.php" method="POST" enctype="multipart/form-data" style="display: none; flex-direction: column;">
      <input type="hidden" name="product_id" id="updateProductHiddenId">
      <input type="text" name="name" id="updateProductName" placeholder="Product Name" required>
      <input type="number" name="price" id="updateProductPrice" placeholder="Price (Rs)" required>
      <textarea name="description" id="updateProductDescription" placeholder="Product Description" required></textarea>

      <label>Available Sizes:</label>
      <select name="sizes[]" id="updateProductSizes" multiple required>
        <option>S</option>
        <option>M</option>
        <option>L</option>
        <option>XL</option>
        <option>XXL</option>
      </select>

      <label><input type="checkbox" name="is_new" id="updateNewArrival"> Mark as New Arrival</label>

      <label>Existing Images:</label>
      <div id="existingImages" class="image-preview"></div>

      <label>Upload New Images (optional):</label>
      <input type="file" name="images[]" multiple accept="image/*" onchange="previewUpdateImages(event)">
      <div id="updateImagePreview" class="image-preview"></div>

      <div style="display: flex; gap: 10px; margin-top: 15px;">
        <button type="submit" style="background-color:#4CAF50;">Update Product</button>
        <button type="button" onclick="confirmDeleteProduct()" style="background-color:#e74c3c;">Delete Product</button>
      </div>
    </form>
  </div>
</section>

<script>
  function showTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    document.querySelector(`.tab-btn[onclick="showTab('${tabId}')"]`).classList.add('active');
  }

  function previewAddImages(event) {
    const preview = document.getElementById('addImagePreview');
    preview.innerHTML = '';
    [...event.target.files].forEach(file => {
      const reader = new FileReader();
      reader.onload = e => {
        const img = document.createElement('img');
        img.src = e.target.result;
        preview.appendChild(img);
      };
      reader.readAsDataURL(file);
    });
  }

  function previewUpdateImages(event) {
    const preview = document.getElementById('updateImagePreview');
    preview.innerHTML = '';
    [...event.target.files].forEach(file => {
      const reader = new FileReader();
      reader.onload = e => {
        const img = document.createElement('img');
        img.src = e.target.result;
        preview.appendChild(img);
      };
      reader.readAsDataURL(file);
    });
  }

  function confirmDeleteProduct() {
    const productId = document.getElementById('updateProductHiddenId').value;
    if (!productId) return alert('No product loaded.');
    const confirmDelete = confirm(`Are you sure you want to delete product '${productId}'?`);
    if (confirmDelete) {
      window.location.href = `delete_product_backend.php?product_id=${productId}`;
    }
  }

  document.getElementById('fetchProductForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const productId = document.getElementById('updateProductId').value;

    fetch('fetch_product.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: 'product_id=' + encodeURIComponent(productId)
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        document.getElementById('updateProductForm').style.display = 'flex';
        document.getElementById('updateProductHiddenId').value = productId;
        document.getElementById('updateProductName').value = data.data.product_name;
        document.getElementById('updateProductPrice').value = data.data.price;
        document.getElementById('updateProductDescription').value = data.data.description;

        const sizes = data.data.sizes ? data.data.sizes.split(',') : [];
        const sizeSelect = document.getElementById('updateProductSizes');
        [...sizeSelect.options].forEach(opt => {
          opt.selected = sizes.includes(opt.value);
        });

        document.getElementById('updateNewArrival').checked = data.data.is_new == 1;

        const existingImagesDiv = document.getElementById('existingImages');
        existingImagesDiv.innerHTML = '';
        if (data.images && data.images.length > 0) {
          data.images.forEach(path => {
            const img = document.createElement('img');
            img.src = path;
            existingImagesDiv.appendChild(img);
          });
        }
      } else {
        alert(data.message);
      }
    })
    .catch(err => {
      console.error('Fetch error:', err);
      alert('Failed to fetch product details.');
    });
  });
</script>




 <!--Order Management -->
 <section id="manageOrders" class="admin-panel px-5 py-4">
  <h2 class="mb-4">Manage Orders</h2>

  <div class="tab-buttons">
    <button id="tabNewOrders" class="tab-btn active" onclick="activateOrderTab('new')">New Orders</button>
    <button id="tabCompletedOrders" class="tab-btn" onclick="activateOrderTab('completed')">Completed Orders</button>
  </div>

  <!-- New Orders -->
  <div id="orderListNew" class="tab-content active">
    <div class="list-group">
      <button class="list-group-item" onclick="showOrderPopup('new', 1)">Name: Imeda | Email: imedha@gmail.com</button>
      <button class="list-group-item" onclick="showOrderPopup('new', 2)">Name: Nimal | Email: nimal@gmail.com</button>
    </div>
  </div>

  <!-- Completed Orders -->
  <div id="orderListCompleted" class="tab-content">
    <div class="list-group">
      <button class="list-group-item" onclick="showOrderPopup('completed', 3)">Name: Tharindu | Email: tharindu@gmail.com</button>
    </div>
  </div>
</section>

<!-- Modal for Order Details -->
<div id="orderModal" class="modal-overlay">
  <div class="modal-content">
    <span class="close-modal" onclick="closeOrderModal()">×</span>

    <h4>Customer Details</h4>
    <p><strong>Name:</strong> <span id="custName"></span></p>
    <p><strong>Email:</strong> <span id="custEmail"></span></p>
    <p><strong>Address:</strong> <span id="custAddress"></span></p>

    <h4 class="mt-3">Ordered Products</h4>
    <div id="productList" class="image-preview"></div>

    <h4 class="mt-3">Bank Slip</h4>
    <img id="bankSlipImg" src="" class="img-fluid" style="max-width:300px; border-radius:5px; border: 1px solid #ccc;">

    <div class="mt-4 d-flex gap-3">
      <button class="btn btn-outline-danger" onclick="confirmCancel()">Cancel Order</button>
      <button class="btn btn-success" id="completeBtn" onclick="alert('Order marked as completed')">Mark as Completed</button>
    </div>
  </div>
</div>




<script>
  const ordersData = {
    new: {
      1: {
        name: "Imeda",
        email: "imedha@gmail.com",
        address: "No. 12, Colombo",
        products: [
          { name: "T-Shirt", id: "P1001", size: "M", qty: 2, price: 1500, image: "assets/dress2.jpg" },
          { name: "Jeans", id: "P1002", size: "L", qty: 1, price: 3000, image: "assets/dress2.jpg" }
        ],
        bankSlip: "assets/dress2.jpg"
      },
      2: {
        name: "Nimal",
        email: "nimal@gmail.com",
        address: "Galle Rd, Panadura",
        products: [
          { name: "Cap", id: "P1003", size: "Free", qty: 1, price: 800, image: "assets/dress2.jpg" }
        ],
        bankSlip: "assets/bankslip2.jpg"
      }
    },
    completed: {
      3: {
        name: "Tharindu",
        email: "tharindu@gmail.com",
        address: "Kandy, Sri Lanka",
        products: [
          { name: "Hoodie", id: "P1004", size: "XL", qty: 1, price: 2500, image: "assets/hoodie.webp" }
        ],
        bankSlip: "assets/bankslip3.jpg"
      }
    }
  };

  function activateOrderTab(type) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));

    document.getElementById(`tab${type.charAt(0).toUpperCase() + type.slice(1)}Orders`).classList.add('active');
    document.getElementById(`orderList${type.charAt(0).toUpperCase() + type.slice(1)}`).classList.add('active');
  }

  function showOrderPopup(type, id) {
    const data = ordersData[type][id];
    if (!data) return;

    document.getElementById("custName").innerText = data.name;
    document.getElementById("custEmail").innerText = data.email;
    document.getElementById("custAddress").innerText = data.address;
    document.getElementById("bankSlipImg").src = data.bankSlip;

    const productList = document.getElementById("productList");
    productList.innerHTML = "";
    data.products.forEach(p => {
      const item = `
        <div>
          <img src="${p.image}" alt="${p.name}">
          <div><strong>${p.name}</strong><br>ID: ${p.id}<br>Size: ${p.size}<br>Qty: ${p.qty}<br>Rs ${p.price}</div>
        </div>
      `;
      productList.insertAdjacentHTML('beforeend', item);
    });

    document.getElementById("completeBtn").style.display = type === "new" ? "inline-block" : "none";
    document.getElementById("orderModal").style.display = "flex";
  }

  function closeOrderModal() {
    document.getElementById("orderModal").style.display = "none";
  }

  function confirmCancel() {
    if (confirm("Are you sure you want to cancel this order?")) {
      alert("Order cancelled.");
      closeOrderModal();
    }
  }
</script>



    <section id="manageNotifications" class="admin-panel" tabindex="0" aria-label="Manage Notifications Section">
      <h1>Manage Notifications</h1>
      <p class="lead">Create and manage system notifications.</p>
      <table>
        <thead>
          <tr><th>Notification ID</th><th>Message</th><th>Date</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <tr><td>#N9001</td><td>New products have been added!</td><td>2025-07-25</td><td><button>Edit</button> <button>Delete</button></td></tr>
          <tr><td>#N9002</td><td>Flash Sale starting tomorrow!</td><td>2025-07-26</td><td><button>Edit</button> <button>Delete</button></td></tr>
        </tbody>
      </table>
    </section>

    <section id="manageEmployees" class="admin-panel" tabindex="0" aria-label="Manage Employees Section">
      <h1>Manage Employees</h1>
      <p class="lead">Add or update employee information.</p>
      <table>
        <thead>
          <tr><th>Employee ID</th><th>Name</th><th>Role</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <tr><td>#E1001</td><td>John Doe</td><td>Manager</td><td><button>Edit</button> <button>Remove</button></td></tr>
          <tr><td>#E1002</td><td>Jane Smith</td><td>Staff</td><td><button>Edit</button> <button>Remove</button></td></tr>
        </tbody>
      </table>
    </section>


<!-- schedule offers -->
 <section id="scheduleOffers" class="admin-panel" tabindex="0" aria-label="Schedule Offers Section">
  <h1>Schedule Offers</h1>
  <p class="lead">Create and schedule promotional offers for selected products.</p>

  <form id="offerForm" style="max-width: 600px;">
    <label for="offerName">Offer Name:</label>
    <input id="offerName" name="offerName" type="text" placeholder="E.g., Summer Sale" required />

    <label for="offerStart">Start Date:</label>
    <input id="offerStart" name="offerStart" type="date" required />

    <label for="offerEnd">End Date:</label>
    <input id="offerEnd" name="offerEnd" type="date" required />

    <hr />

    <div id="productInputs">
      <label for="productId">Product ID:</label>
      <input id="productId" type="text" placeholder="Enter Product ID" />

      <label for="discount">Discount %:</label>
      <input id="discount" type="number" placeholder="E.g., 20" min="1" max="100" />

      <button type="button" onclick="addDiscountedProduct()">Add Product</button>
    </div>

    <h3>Discounted Products List</h3>
    <table id="discountedList">
      <thead>
        <tr>
          <th>Product ID</th>
          <th>Name</th>
          <th>Old Price</th>
          <th>Discount %</th>
          <th>New Price</th>
          <th>Remove</th>
        </tr>
      </thead>
      <tbody id="discountedListBody">
        <!-- JS will populate -->
      </tbody>
    </table>

    <br />
    <button type="submit">Schedule Offer</button>
  </form>

  <hr />
  <h2>Scheduled Offers</h2>

  <?php
  include 'db.php';

  $offersQuery = "
    SELECT 
      o.offer_id, o.offer_name, o.start_date, o.end_date,
      p.product_id, p.name AS product_name,
      op.old_price, op.discount_percent, op.new_price
    FROM offers o
    JOIN offer_products op ON o.offer_id = op.offer_id
    JOIN products p ON op.product_id = p.product_id
    ORDER BY o.offer_id DESC
  ";

  $offersResult = mysqli_query($conn, $offersQuery);
  $offers = [];

  while ($row = mysqli_fetch_assoc($offersResult)) {
    $offerId = $row['offer_id'];
    if (!isset($offers[$offerId])) {
      $offers[$offerId] = [
        'offer_name' => $row['offer_name'],
        'start_date' => $row['start_date'],
        'end_date' => $row['end_date'],
        'products' => []
      ];
    }
    $offers[$offerId]['products'][] = $row;
  }
  ?>

  <?php if (!empty($offers)): ?>
    <?php foreach ($offers as $offerId => $offer): ?>
      <div style="border: 1px solid #ccc; padding: 15px; margin-bottom: 20px; border-radius: 8px;">
        <h3><?= htmlspecialchars($offer['offer_name']) ?></h3>
        <p><strong>Start:</strong> <?= $offer['start_date'] ?> | <strong>End:</strong> <?= $offer['end_date'] ?></p>

        <table border="1" cellpadding="8" cellspacing="0" style="width: 100%; margin-top: 10px;">
          <thead>
            <tr>
              <th>Product ID</th>
              <th>Name</th>
              <th>Old Price</th>
              <th>Discount %</th>
              <th>New Price</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($offer['products'] as $product): ?>
              <tr>
                <td><?= htmlspecialchars($product['product_id']) ?></td>
                <td><?= htmlspecialchars($product['product_name']) ?></td>
                <td>Rs. <?= number_format($product['old_price'], 2) ?></td>
                <td><?= $product['discount_percent'] ?>%</td>
                <td>Rs. <?= number_format($product['new_price'], 2) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <br />
        <form method="POST" action="delete_offer.php" onsubmit="return confirm('Are you sure you want to delete this offer?');">
          <input type="hidden" name="offer_id" value="<?= $offerId ?>">
          <button type="submit" style="background-color: red; color: white; padding: 8px 16px; border: none; border-radius: 5px;">Remove Offer</button>
        </form>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p>No scheduled offers available.</p>
  <?php endif; ?>
</section>

<script>
  const discountedProducts = [];

  function addDiscountedProduct() {
    const productId = document.getElementById('productId').value.trim();
    const discount = parseFloat(document.getElementById('discount').value.trim());

    if (!productId || isNaN(discount) || discount < 1 || discount > 100) {
      alert("Please enter valid product ID and discount %");
      return;
    }

    fetch('fetch_product.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'product_id=' + encodeURIComponent(productId)
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          const existing = discountedProducts.find(p => p.product_id === productId);
          if (existing) {
            alert("Product already added.");
            return;
          }

          const price = parseFloat(data.data.price);
          const newPrice = (price - (price * discount / 100)).toFixed(2);

          const product = {
            product_id: productId,
            name: data.data.product_name,
            old_price: price.toFixed(2),
            discount: discount,
            new_price: newPrice
          };

          discountedProducts.push(product);
          renderDiscountedList();
          document.getElementById('productId').value = '';
          document.getElementById('discount').value = '';
        } else {
          alert(data.message || "Product not found.");
        }
      })
      .catch(err => {
        console.error(err);
        alert("Error fetching product.");
      });
  }

  function renderDiscountedList() {
    const tbody = document.getElementById('discountedListBody');
    tbody.innerHTML = '';
    discountedProducts.forEach((p, index) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${p.product_id}</td>
        <td>${p.name}</td>
        <td>Rs. ${p.old_price}</td>
        <td>${p.discount}%</td>
        <td>Rs. ${p.new_price}</td>
        <td><button type="button" onclick="removeProduct(${index})">Remove</button></td>
      `;
      tbody.appendChild(row);
    });
  }

  function removeProduct(index) {
    discountedProducts.splice(index, 1);
    renderDiscountedList();
  }

  document.getElementById('offerForm').addEventListener('submit', function (e) {
    e.preventDefault();

    if (discountedProducts.length === 0) {
      alert("Please add at least one product.");
      return;
    }

    const formData = {
      offerName: document.getElementById('offerName').value.trim(),
      startDate: document.getElementById('offerStart').value,
      endDate: document.getElementById('offerEnd').value,
      products: discountedProducts
    };

    fetch('schedule_offer.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          alert("Offer scheduled successfully!");
          discountedProducts.length = 0;
          renderDiscountedList();
          document.getElementById('offerForm').reset();
          window.location.reload(); // Reload to show updated list
        } else {
          alert("Error: " + data.message);
        }
      })
      .catch(err => {
        console.error(err);
        alert("Failed to schedule offer.");
      });
  });
</script>








    <section id="customerInquiries" class="admin-panel" tabindex="0" aria-label="Customer Inquiries Section">
      <h1>Customer Inquiries</h1>
      <p class="lead">View customer questions and messages.</p>
      <ul id="inquiryList" aria-live="polite">
        <li><strong>Mary:</strong> "Do you have more sizes available for the Floral Dress?"</li>
        <li><strong>Raj:</strong> "Can I change my delivery address?"</li>
        <li><strong>Alice:</strong> "Is the summer collection arriving soon?"</li>
        <li><strong>David:</strong> "What is your return policy?"</li>
      </ul>
    </section>
  </main>

  <script>
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".sidebar .toggle-btn");
    const navLinks = document.querySelectorAll("nav button.nav-link");
    const panels = document.querySelectorAll("section.admin-panel");
    const notificationsIcon = document.querySelector(".notifications");
    const notifBadge = document.getElementById("notifBadge");
    const adminProfile = document.querySelector(".admin-profile");
    const profileDropdown = document.getElementById("profileDropdown");

    // Toggle sidebar collapsed state
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("collapsed");
    });
    toggleBtn.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        sidebar.classList.toggle("collapsed");
      }
    });

    // Navigation button click to show panel
    function deactivateAll() {
      navLinks.forEach(link => link.classList.remove("active"));
      panels.forEach(panel => panel.classList.remove("active"));
    }
    navLinks.forEach(link => {
      link.addEventListener("click", () => {
        deactivateAll();
        link.classList.add("active");
        const target = link.getAttribute("data-target");
        document.getElementById(target).classList.add("active");
      });
    });

    // Notification icon click shows inquiries
    notificationsIcon.addEventListener("click", () => {
      deactivateAll();
      // Activate inquiries nav button & panel
      navLinks.forEach(link => {
        if(link.getAttribute("data-target") === "customerInquiries"){
          link.classList.add("active");
        } else {
          link.classList.remove("active");
        }
      });
      document.getElementById("customerInquiries").classList.add("active");
    });
    notificationsIcon.addEventListener("keydown", e => {
      if(e.key === "Enter" || e.key === " "){
        e.preventDefault();
        notificationsIcon.click();
      }
    });

    // Admin profile toggle dropdown
    adminProfile.addEventListener("click", () => {
      const expanded = adminProfile.getAttribute("aria-expanded") === "true";
      adminProfile.setAttribute("aria-expanded", !expanded);
      profileDropdown.classList.toggle("active");
      profileDropdown.setAttribute("aria-hidden", expanded);
    });
    adminProfile.addEventListener("keydown", e => {
      if(e.key === "Enter" || e.key === " "){
        e.preventDefault();
        adminProfile.click();
      }
    });

    // Close dropdown if clicking outside
    document.addEventListener("click", e => {
      if (!adminProfile.contains(e.target)) {
        adminProfile.setAttribute("aria-expanded", false);
        profileDropdown.classList.remove("active");
        profileDropdown.setAttribute("aria-hidden", true);
      }
    });

    // Logout button action (placeholder)
    document.getElementById("logoutBtn").addEventListener("click", () => {
      alert("Logging out...");
      // Add logout logic here
    });
  </script>
</body>
</html>