<?php
include 'db.php';

// Sanitize inputs
$productId = $_POST['product_id'];
$name = $_POST['name'];
$price = $_POST['price'];
$description = $_POST['description'];
$sizes = implode(",", $_POST['sizes'] ?? []);
$isNew = isset($_POST['is_new']) ? 1 : 0;

// Handle image uploads
$uploadDir = "/Applications/XAMPP/xamppfiles/htdocs/MaxFashionConnect/customer/uploads/";
$imageNames = [];

for ($i = 0; $i < 4; $i++) {
    if (isset($_FILES['images']['name'][$i]) && $_FILES['images']['name'][$i] != "") {
        // Clean file name (replace spaces/special chars)
        $fileName = preg_replace("/[^A-Za-z0-9_\-\.]/", "_", basename($_FILES['images']['name'][$i]));
        $tmpName = $_FILES['images']['tmp_name'][$i];
        $targetPath = $uploadDir . $fileName;

        if (move_uploaded_file($tmpName, $targetPath)) {
            $imageNames[] = $fileName; // Save only the name in DB
        } else {
            $imageNames[] = null;
        }
    } else {
        $imageNames[] = null;
    }
}

// Fill missing image slots with null
while (count($imageNames) < 4) {
    $imageNames[] = null;
}

// Insert into database
$stmt = $conn->prepare("INSERT INTO products 
(product_id, name, price, description, sizes, is_new_arrival, image1, image2, image3, image4) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param(
    "ssdsssssss",
    $productId,
    $name,
    $price,
    $description,
    $sizes,
    $isNew,
    $imageNames[0],
    $imageNames[1],
    $imageNames[2],
    $imageNames[3]
);

if ($stmt->execute()) {
    echo "<script>alert('Product added successfully!'); window.location.href='adminS.php';</script>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
