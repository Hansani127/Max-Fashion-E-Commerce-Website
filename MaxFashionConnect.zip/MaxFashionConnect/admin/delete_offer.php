<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['offer_id'])) {
  $offer_id = intval($_POST['offer_id']);

  mysqli_query($conn, "DELETE FROM offer_products WHERE offer_id = $offer_id");
  mysqli_query($conn, "DELETE FROM offers WHERE offer_id = $offer_id");

  header("Location: adminS.php");
  exit();
}
?>
