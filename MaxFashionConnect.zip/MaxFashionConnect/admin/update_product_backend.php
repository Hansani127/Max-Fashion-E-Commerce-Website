<?php
include 'db.php';

$productId = $_POST['product_id'];
$name = $_POST['name'];
$price = $_POST['price'];
$description = $_POST['description'];
$sizes = implode(",", $_POST['sizes'] ?? []);
$isNew = isset($_POST['is_new']) ? 1 : 0;

$uploadDir = "/Applications/XAMPP/xamppfiles/htdocs/MaxFashionConnect/uploads/";

// First, fetch existing images for the product
$stmt = $conn->prepare("SELECT image1, image2, image3, image4 FROM products WHERE product_id = ?");
$stmt->bind_param("s", $productId);
$stmt->execute();
$result = $stmt->get_result();
$existingImages = [null, null, null, null];

if ($row = $result->fetch_assoc()) {
    $existingImages[0] = $row['image1'];
    $existingImages[1] = $row['image2'];
    $existingImages[2] = $row['image3'];
    $existingImages[3] = $row['image4'];
}
$stmt->close();

// Prepare array to hold final image names to save in DB
$imageNames = $existingImages;

// Check if new images uploaded and move them; replace old names if uploaded
if (!empty($_FILES['images']['name'][0])) {
    // Loop max 4 images, update only those uploaded
    for ($i = 0; $i < 4; $i++) {
        if (isset($_FILES['images']['name'][$i]) && $_FILES['images']['name'][$i] != "") {
            // Clean filename
            $fileName = preg_replace("/[^A-Za-z0-9_\-\.]/", "_", basename($_FILES['images']['name'][$i]));
            $tmpName = $_FILES['images']['tmp_name'][$i];
            $targetPath = $uploadDir . $fileName;

            if (move_uploaded_file($tmpName, $targetPath)) {
                $imageNames[$i] = $fileName;
            }
        }
    }
}

// Update the product record with new details and image names
$stmt = $conn->prepare("UPDATE products SET name=?, price=?, description=?, sizes=?, is_new_arrival=?, image1=?, image2=?, image3=?, image4=? WHERE product_id=?");
$stmt->bind_param(
    "sdssisssss",
    $name,
    $price,
    $description,
    $sizes,
    $isNew,
    $imageNames[0],
    $imageNames[1],
    $imageNames[2],
    $imageNames[3],
    $productId
);

if ($stmt->execute()) {
    echo "<script>alert('Product updated successfully!'); window.location.href='adminS.php';</script>";
} else {
    echo "Error updating product: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
