<?php
include 'db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['products']) || !is_array($data['products'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
    exit;
}

$offerName = $data['offer_name'];
$startDate = $data['start_date'];
$endDate = $data['end_date'];
$products = $data['products'];

$stmt = $conn->prepare("INSERT INTO scheduled_offers (offer_name, product_id, original_price, discounted_price, discount_percentage, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?)");

foreach ($products as $product) {
    $stmt->bind_param(
        "ssddiis",
        $offerName,
        $product['product_id'],
        $product['original_price'],
        $product['discounted_price'],
        $product['discount_percentage'],
        $startDate,
        $endDate
    );
    $stmt->execute();
}

$stmt->close();
$conn->close();

echo json_encode(['success' => true]);
?>
