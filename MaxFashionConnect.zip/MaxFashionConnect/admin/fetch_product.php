<?php
include 'db.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'data' => null, 'images' => []];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    // Get product details
    $stmt = $conn->prepare("SELECT name, price, description, sizes, is_new_arrival FROM products WHERE product_id = ?");
    $stmt->bind_param("s", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($product = $result->fetch_assoc()) {
        // Fetch associated images (assuming image1..image4 fields in products table)
        $images = [];
        for ($i = 1; $i <= 4; $i++) {
            $imgField = 'image' . $i;
            if (!empty($product[$imgField])) {
                $images[] = "uploads/" . $product[$imgField];
            }
        }

        // Or if you have separate product_images table, replace above with query fetching image_path where product_id=?

        $response['success'] = true;
        $response['data'] = [
            'product_name' => $product['name'],
            'price' => $product['price'],
            'description' => $product['description'],
            'sizes' => $product['sizes'],
            'is_new' => $product['is_new_arrival']
        ];
        $response['images'] = $images;
    } else {
        $response['message'] = "Product not found.";
    }

    $stmt->close();
    $conn->close();
} else {
    $response['message'] = "Invalid request.";
}

echo json_encode($response);
?>
