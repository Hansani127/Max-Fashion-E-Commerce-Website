

<?php
require 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // First check if it's an admin
    $adminStmt = $conn->prepare("SELECT id, email, password FROM admins WHERE email = ?");
    $adminStmt->bind_param("s", $email);
    $adminStmt->execute();
    $adminResult = $adminStmt->get_result();

    if ($admin = $adminResult->fetch_assoc()) {
        if ($password === $admin['password']) {  // Plain-text password for admin as per your insert
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $admin['id'];
            header("Location: /MaxFashionConnect/admin/adminS.php");
            exit();
        } else {
            echo "Incorrect admin password.";
            exit();
        }
    }

    // Now check if it's a customer
    $stmt = $conn->prepare("SELECT id, first_name, email, contact, password FROM customers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['customer_logged_in'] = true;
            $_SESSION['customer_id'] = $user['id'];
            $_SESSION['customer_name'] = $user['first_name'];
            $_SESSION['customer_phone'] = $user['contact'];
            header("Location: CustomerS.php"); // Change to your customer homepage
            exit();
        } else {
            echo "Incorrect password.";
        }
    } else {
        echo "No user found with that email.";
    }
}
?>
