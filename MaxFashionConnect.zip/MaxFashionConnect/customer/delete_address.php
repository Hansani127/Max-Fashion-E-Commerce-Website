<?php
session_start();
require 'db.php';

if (!isset($_SESSION['customer_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$addressId = intval($data['address_id']);
$customerId = $_SESSION['customer_id'];

$stmt = $conn->prepare("DELETE FROM customer_addresses WHERE id = ? AND customer_id = ?");
$stmt->bind_param("ii", $addressId, $customerId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to delete']);
}
