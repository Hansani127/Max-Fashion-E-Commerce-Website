<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $contact = $_POST['contact'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $confirm = $_POST['confirm_password'];
  $address = $_POST['address'] ?? null;

  if ($password !== $confirm) {
    header("Location: CustomerS.php?error=Passwords do not match.");
    exit();
  }

  // Check if email already exists
  $check = $conn->prepare("SELECT id FROM customers WHERE email = ?");
  $check->bind_param("s", $email);
  $check->execute();
  $check->store_result();
  if ($check->num_rows > 0) {
    header("Location: CustomerS.php?error=Email already registered.");
    exit();
  }

  // Hash password
  $hash = password_hash($password, PASSWORD_DEFAULT);

  // Insert new customer
  $stmt = $conn->prepare("INSERT INTO customers (first_name, last_name, contact, email, password) VALUES (?, ?, ?, ?, ?)");
  $stmt->bind_param("sssss", $fname, $lname, $contact, $email, $hash);

  if ($stmt->execute()) {
    header("Location: CustomerS.php?registered=1");
    exit();
  } else {
    header("Location: CustomerS.php?error=Registration failed.");
    exit();
  }
}
?>
