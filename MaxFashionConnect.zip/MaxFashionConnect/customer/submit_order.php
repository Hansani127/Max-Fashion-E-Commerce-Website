<?php
// DB connection
$conn = new mysqli("localhost", "root", "", "your_db");

$name = $_POST['customer_name'];
$email = $_POST['customer_email'];
$totalItems = $_POST['total_items'];
$totalPrice = $_POST['total_price'];
$cartData = json_decode($_POST['cart_data'], true);

// Handle slip upload
$targetDir = "uploads/";
$filename = basename($_FILES["bank_slip"]["name"]);
$targetFile = $targetDir . time() . "_" . $filename;
move_uploaded_file($_FILES["bank_slip"]["tmp_name"], $targetFile);

// Insert order
$conn->query("INSERT INTO orders (customer_name, customer_email, total_items, total_price, bank_slip_path) 
              VALUES ('$name', '$email', $totalItems, $totalPrice, '$targetFile')");
$orderId = $conn->insert_id;

// Insert items
foreach ($cartData as $item) {
    $product = $conn->real_escape_string($item['name']);
    $size = $item['size'];
    $qty = $item['quantity'];
    $price = $item['price'];
    $conn->query("INSERT INTO order_items (order_id, product_name, size, quantity, price) 
                  VALUES ($orderId, '$product', '$size', $qty, $price)");
}

echo "<script>alert('Order Placed Successfully');window.location.href='index.html';</script>";
?>
