<?php
session_start();
$registered = isset($_GET['registered']);
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login & Signup - Max Fashion</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f5f5f5;
    }
    .auth-container {
      max-width: 500px;
      margin: 60px auto;
      padding: 30px;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    .nav-tabs .nav-link.active {
      background-color: #000;
      color: white;
    }
  </style>
</head>
<body>

<div class="auth-container">
  <h3 class="text-center mb-4">Welcome to Max Fashion</h3>

  <!-- Tabs -->
  <ul class="nav nav-tabs mb-4" id="authTab" role="tablist">
    <li class="nav-item">
      <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login" type="button" role="tab">Login</button>
    </li>
    <li class="nav-item">
      <button class="nav-link" id="signup-tab" data-bs-toggle="tab" data-bs-target="#signup" type="button" role="tab">Sign Up</button>
    </li>
  </ul>

  <div class="tab-content">
    <!-- Login Tab -->
    <div class="tab-pane fade show active" id="login" role="tabpanel">
      <?php if ($registered): ?>
        <div class="alert alert-success">✅ Registration successful! Please log in.</div>
      <?php endif; ?>
      <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form action="login.php" method="POST">
        <div class="mb-3">
          <label>Email</label>
          <input type="email" class="form-control" name="email" required>
        </div>
        <div class="mb-3">
          <label>Password</label>
          <input type="password" class="form-control" name="password" required>
        </div>
        <button class="btn btn-dark w-100" type="submit">Login</button>
      </form>
    </div>

    <!-- Sign Up Tab -->
    <div class="tab-pane fade" id="signup" role="tabpanel">
      <form action="signup.php" method="POST" id="signupForm">
        <!-- Basic Info -->
        <div id="basicInfoSection">
          <div class="row">
            <div class="col mb-3">
              <label>First Name</label>
              <input type="text" class="form-control" name="fname" required>
            </div>
            <div class="col mb-3">
              <label>Last Name</label>
              <input type="text" class="form-control" name="lname" required>
            </div>
          </div>
          <div class="mb-3">
            <label>Contact Number</label>
            <input type="text" class="form-control" name="contact" required>
          </div>
          <div class="mb-3">
            <label>Email</label>
            <input type="email" class="form-control" name="email" required>
          </div>
          <div class="mb-3">
            <label>Password</label>
            <input type="password" class="form-control" name="password" id="password" required>
          </div>
          <div class="mb-3">
            <label>Confirm Password</label>
            <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>
          </div>

          <!-- Trigger -->
          <button type="button" class="btn btn-primary w-100" id="askAddressBtn">Sign Up</button>
        </div>

        <!-- Address Prompt -->
        <div id="addressPrompt" class="text-center mt-4" style="display:none;">
          <p>Do you want to add your delivery address?</p>
          <button type="button" class="btn btn-success me-2" id="yesAddressBtn">Yes</button>
          <button type="submit" class="btn btn-secondary" id="noAddressBtn">No, Register</button>
        </div>

        <!-- Address Section -->
        <div id="addressSection" style="display:none;">
          <div class="mb-3">
            <label>Street 1</label>
            <input type="text" class="form-control" name="street1" required>
          </div>
          <div class="mb-3">
            <label>Street 2</label>
            <input type="text" class="form-control" name="street2">
          </div>
          <div class="mb-3">
            <label>City</label>
            <input type="text" class="form-control" name="city" required>
          </div>
          <div class="mb-3">
            <label>Postal Code</label>
            <input type="text" class="form-control" name="postal_code" required>
          </div>
          <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-dark">Save Address & Register</button>
            <button type="button" class="btn btn-outline-secondary" id="cancelAddressBtn">Cancel</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Signup Flow JS -->
<script>
  const askAddressBtn = document.getElementById('askAddressBtn');
  const addressPrompt = document.getElementById('addressPrompt');
  const basicInfoSection = document.getElementById('basicInfoSection');
  const addressSection = document.getElementById('addressSection');
  const cancelAddressBtn = document.getElementById('cancelAddressBtn');
  const yesAddressBtn = document.getElementById('yesAddressBtn');

  askAddressBtn.addEventListener('click', function () {
    const pwd = document.getElementById('password').value;
    const cpwd = document.getElementById('confirm_password').value;
    if (pwd !== cpwd) {
      alert("Passwords do not match!");
      return;
    }
    basicInfoSection.style.display = 'none';
    addressPrompt.style.display = 'block';
  });

  yesAddressBtn.addEventListener('click', function () {
    addressPrompt.style.display = 'none';
    addressSection.style.display = 'block';
  });

  cancelAddressBtn.addEventListener('click', function () {
    addressSection.style.display = 'none';
    addressPrompt.style.display = 'block';
  });


  const noAddressBtn = document.getElementById('noAddressBtn');

  noAddressBtn.addEventListener('click', function () {
    // Disable address fields before submit
    const addressInputs = addressSection.querySelectorAll('input');
    addressInputs.forEach(input => input.disabled = true);
  });

</script>

</body>
</html>
