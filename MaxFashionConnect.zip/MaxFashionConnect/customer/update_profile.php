<?php
session_start();
require 'db.php';

header('Content-Type: application/json');

// Check login
if (!isset($_SESSION['customer_id'])) {
  echo json_encode(['success' => false, 'message' => 'Unauthorized']);
  exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$name = trim($data['name'] ?? '');
$phone = trim($data['phone'] ?? '');

if ($name === '' || $phone === '') {
  echo json_encode(['success' => false, 'message' => 'All fields are required']);
  exit;
}

$customerId = $_SESSION['customer_id'];

// Update query
$stmt = $conn->prepare("UPDATE customers SET first_name = ?, contact = ? WHERE id = ?");
$stmt->bind_param("ssi", $name, $phone, $customerId);

if ($stmt->execute()) {
  echo json_encode(['success' => true]);
} else {
  echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
