<?php
// Enable error reporting during development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// DB config
$host = "localhost";
$username = "root";
$password = "";
$database = "MaxFashion";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Sanitize and validate POST inputs
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');

if ($name === '' || $email === '' || $message === '') {
    echo "<script>alert('All fields are required.'); window.history.back();</script>";
    exit;
}

// Use prepared statement to insert data
$stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $message);

if ($stmt->execute()) {
    echo "<script>alert('Message sent successfully!'); window.location.href='CustomerS.php';</script>";
} else {
    echo "<script>alert('Error saving message.'); window.history.back();</script>";
}

$stmt->close();
$conn->close();
?>
