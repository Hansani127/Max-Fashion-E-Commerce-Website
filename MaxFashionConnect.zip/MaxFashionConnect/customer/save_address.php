<?php
session_start();
require 'db.php'; // your database connection

// Check if customer is logged in
if (!isset($_SESSION['customer_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);
$street1 = trim($data['street1'] ?? '');
$street2 = trim($data['street2'] ?? '');
$city = trim($data['city'] ?? '');
$postalCode = trim($data['postalCode'] ?? '');
$customerId = $_SESSION['customer_id'];

// Validate
if ($street1 === '' || $city === '' || $postalCode === '') {
    echo json_encode(['success' => false, 'message' => 'Required fields missing']);
    exit;
}

// Insert into database
$stmt = $conn->prepare("INSERT INTO customer_addresses (customer_id, street1, street2, city, postal_code) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("issss", $customerId, $street1, $street2, $city, $postalCode);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'DB error']);
}
?>
