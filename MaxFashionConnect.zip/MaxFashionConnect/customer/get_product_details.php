<?php
include 'db.php'; // your DB connection

$productId = $_GET['id'];
$response = [];

$query = $conn->prepare("SELECT * FROM products WHERE id = ?");
$query->bind_param("i", $productId);
$query->execute();
$result = $query->get_result();

if ($row = $result->fetch_assoc()) {
  $response['name'] = $row['name'];
  $response['price'] = $row['price'];
  $response['description'] = $row['description'];
  $response['code'] = $row['product_code'];

  // Sizes: assuming saved as comma-separated string like "S,M,L,XL"
  $response['sizes'] = explode(",", $row['sizes']);

  // Images: assuming saved as image1,image2,image3 in DB
  $response['images'] = [];
  for ($i = 1; $i <= 4; $i++) {
    $img = $row["image$i"];
    if (!empty($img)) {
      $response['images'][] = "uploads/" . $img;
    }
  }
}

echo json_encode($response);
?>
