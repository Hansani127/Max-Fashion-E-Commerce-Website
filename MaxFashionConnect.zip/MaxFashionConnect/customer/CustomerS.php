

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Max Fashion - Ladies' Style Hub</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/customer.css">
  <link rel="stylesheet" href="css/responsive.css">

  <style>


    @keyframes fadeSlider {
  0%    { background-image: url('assets/back1.jpg'); }
  25%   { background-image: url('assets/back3.webp'); }
  50%   { background-image: url('assets/back4.jpg'); }
  75%   { background-image: url('assets/back5.avif'); }
  100%  { background-image: url('assets/back1.jpg'); }
}
  </style>

</head>


<body>


    <div class="page-wrapper">

  <header>
   
    <div class="logo-container">
  <img src="assets/logooo.jpeg" alt="Max Fashion Logo" class="logo">
</div>


<!-- Menu Toggle Button for Small Screens -->
<button class="menu-toggle" id="menuToggle">
  <i class="bi bi-list"></i>
</button>

<!-- Left Side Navigation -->
<nav class="main-nav" id="mainNav">
  <a href="#" class="nav-link">Home</a>
  <a href="#new" class="nav-link">New Arrivals</a>
  <a href="#discounted" class="nav-link">Discounts</a>
  <a href="#all" class="nav-link">All Products</a>
  <a href="#contact" class="nav-link">Contact Us</a>

  <?php session_start(); ?>
  <div class="icon-group" aria-label="User actions">
    <?php if (!isset($_SESSION['customer_id'])): ?>
      <a href="auth.php"><i class="bi bi-bell"></i></a>
      <a href="auth.php"><i class="bi bi-cart"></i></a>
      <a href="auth.php"><i class="bi bi-person-circle"></i></a>
      <a href="auth.php"><i class="bi bi-box-arrow-in-right"></i></a>
    <?php else: ?>
      <i class="bi bi-bell" id="notifIcon" role="button" tabindex="0"></i>
      <i class="bi bi-cart" id="cartIcon" role="button" tabindex="0" onclick="toggleCartSection()"></i>
      <i class="bi bi-person-circle" id="profileIcon" role="button" tabindex="0"></i>
      <a href="logout.php"><i class="bi bi-box-arrow-right"></i></a>
    <?php endif; ?>
  </div>

  </nav>

    




  <!-- Notification Panel -->
<div class="notification-panel" id="notificationPanel">
  <div class="notification-header">
    <div class="tabs">
      <span class="tab active" onclick="showTab('orders')">Order Updates</span>
      <span class="tab" onclick="showTab('replies')">Replies</span>
      <span class="tab" onclick="showTab('offers')">New Offers</span>
    </div>
    <span class="clear-all" onclick="clearAllNotifications()">Clear All</span>
  </div>

  <div class="notification-content">
    <div class="tab-content" id="orders">
      <div class="notification-item">📦 Your order #12345 has been delivered.
        <button class="clear-btn" onclick="this.parentElement.remove()">✖</button>
      </div>
    </div>

    <div class="tab-content" id="replies" style="display:none;">
      <div class="notification-item">📩 We’ve replied to your message.
        <button class="clear-btn" onclick="this.parentElement.remove()">✖</button>
      </div>
    </div>

    <div class="tab-content" id="offers" style="display:none;">
      <div class="notification-item">🎉 10% OFF on Skirts
        <button class="clear-btn" onclick="this.parentElement.remove()">✖</button>
      </div>
    </div>
  </div>
</div>

  

  </header>


<script>
  const bellIcon = document.querySelector('.bi-bell');
  const panel = document.getElementById('notificationPanel');

  bellIcon.addEventListener('click', function (event) {
    event.stopPropagation();
    panel.style.display = panel.style.display === 'block' ? 'none' : 'block';
  });

  document.addEventListener('click', function () {
    panel.style.display = 'none';
  });

  panel.addEventListener('click', function (event) {
    event.stopPropagation(); // Prevent closing when clicking inside
  });

  function showTab(tabId) {
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach(el => el.style.display = 'none');

    document.getElementById(tabId).style.display = 'block';

    document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
    document.querySelector(`.tab[onclick*="${tabId}"]`).classList.add('active');
  }

  function clearAllNotifications() {
    document.querySelectorAll('.tab-content').forEach(tab => tab.innerHTML = '');
  }
</script>




<script>
  const menuToggle = document.getElementById('menuToggle');
  const mainNav = document.getElementById('mainNav');

  // Show/Hide nav
  menuToggle.addEventListener('click', () => {
    mainNav.classList.toggle('active');
  });

  // Close nav on clicking anywhere outside or on a link/icon
  document.addEventListener('click', (event) => {
    const isClickInside = mainNav.contains(event.target) || menuToggle.contains(event.target);

    if (!isClickInside) {
      mainNav.classList.remove('active');
    }

    // Also close when any link/icon inside nav is clicked
    if (event.target.closest('.nav-link') || event.target.closest('.icon-group i')) {
      mainNav.classList.remove('active');
    }
  });
</script>








<!-- Profile Popup Modal -->
<div id="profileModal" class="modal-overlay">
  <div class="modal-content">
    <span class="close-modal" id="closeProfileModal">&times;</span>
    <h2 class="modal-title">My Profile 
      <i class="bi bi-pencil-square edit-icon" id="editProfileBtn" title="Edit"></i>
    </h2>

    <form id="profileForm">
      <div class="profile-group">
        <label>Username</label>
        <input type="text" id="username" disabled>
      </div>
      <div class="profile-group">
        <label>Email</label>
        <input type="email" id="email" disabled>
      </div>
      <div class="profile-group">
        <label>Phone Number</label>
        <input type="text" id="phone" disabled>
      </div>
      <div id="updateProfileControls" style="display:none; margin-top:10px;">
        <button type="button" class="btn-primary" id="updateBtn">Update</button>
        <button type="button" class="btn-secondary" id="cancelEditBtn">Cancel</button>
      </div>
    </form>

    <p id="changePasswordLink" class="link-word">Change Password</p>

    <form id="changePasswordForm" style="display:none;">
      <div class="profile-group">
        <label>Old Password</label>
        <input type="password" id="oldPassword">
      </div>
      <div class="profile-group">
        <label>New Password</label>
        <input type="password" id="newPassword">
      </div>
      <div class="profile-group">
        <label>Confirm New Password</label>
        <input type="password" id="confirmPassword">
      </div>
      <p class="forgot-password">Forgot Password?</p>
      <button type="button" class="btn-primary" id="updatePasswordBtn">Update Password</button>
    </form>

    <hr>

    <div class="address-section">
      <div class="address-header">
        <h3>Delivery Addresses</h3>
        <button type="button" id="toggleAddressForm">&#x2212;</button>
      </div>
      <div id="addressList"></div>
      <div id="addressFormContainer">
        <form id="addressForm">
          <input type="text" placeholder="Street 1" id="street1" required>
          <input type="text" placeholder="Street 2" id="street2">
          <input type="text" placeholder="City" id="city" required>
          <input type="text" placeholder="Postal Code" id="postalCode" required>
          <button type="submit" class="savebtn">Save Address</button>
        </form>
      </div>
    </div>

    <hr>

    <div class="account-actions">
      <button class="btn-secondary" id="logoutBtn">Logout</button>
      <button class="btn-danger" id="deleteAccountBtn">Delete Account</button>
    </div>
  </div>
</div>

<script>
const profileIcon = document.querySelector(".bi-person-circle");
const profileModal = document.getElementById("profileModal");
const closeBtn = document.getElementById("closeProfileModal");
const body = document.body;

// Profile Modal Show
profileIcon.addEventListener("click", () => {
  profileModal.style.display = "flex";
  body.classList.add("modal-open");

  // Fetch real user data
  fetch("fetch_user_profile.php")
    .then(res => {
      if (!res.ok) throw new Error("Not authorized");
      return res.json();
    })
    .then(data => {
      document.getElementById("username").value = data.first_name || "";
      document.getElementById("email").value = data.email || "";
      document.getElementById("phone").value = data.contact || "";
    })
    .catch(err => {
      console.error(err);
      alert("Failed to load profile info.");
    });
});

closeBtn.addEventListener("click", () => {
  profileModal.style.display = "none";
  body.classList.remove("modal-open");
});

// Edit & Update
const editBtn = document.getElementById("editProfileBtn");
const updateBtn = document.getElementById("updateBtn");
const cancelBtn = document.getElementById("cancelEditBtn");
const updateControls = document.getElementById("updateProfileControls");
const username = document.getElementById("username");
const phone = document.getElementById("phone");

editBtn.addEventListener("click", () => {
  username.disabled = false;
  phone.disabled = false;
  updateControls.style.display = "block";
});

cancelBtn.addEventListener("click", () => {
  username.disabled = true;
  phone.disabled = true;
  updateControls.style.display = "none";
});

updateBtn.addEventListener("click", () => {
  const updatedName = username.value.trim();
  const updatedPhone = phone.value.trim();

  fetch("update_profile.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ name: updatedName, phone: updatedPhone })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      alert("Profile updated successfully!");
      username.disabled = true;
      phone.disabled = true;
      updateControls.style.display = "none";
    } else {
      alert(data.message || "Update failed.");
    }
  })
  .catch(err => {
    console.error(err);
    alert("Server error.");
  });
});


// Change Password Toggle
document.getElementById("changePasswordLink").addEventListener("click", () => {
  const pwdForm = document.getElementById("changePasswordForm");
  pwdForm.style.display = pwdForm.style.display === "none" ? "block" : "none";
});

// Address Form Toggle
const toggleAddressForm = document.getElementById("toggleAddressForm");
const addressFormContainer = document.getElementById("addressFormContainer");

toggleAddressForm.addEventListener("click", () => {
  const isHidden = addressFormContainer.style.display === "none";
  addressFormContainer.style.display = isHidden ? "block" : "none";
  toggleAddressForm.innerHTML = isHidden ? "&#x2212;" : "&#x2b;";
});

// Address Logic
const addressForm = document.getElementById("addressForm");
const addressList = document.getElementById("addressList");

addressForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const street1 = document.getElementById("street1").value.trim();
  const street2 = document.getElementById("street2").value.trim();
  const city = document.getElementById("city").value.trim();
  const postalCode = document.getElementById("postalCode").value.trim();

  fetch("save_address.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ street1, street2, city, postalCode })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      const item = document.createElement("div");
      item.classList.add("address-item");
      item.innerHTML = `
        <p>${street1}, ${street2}, ${city}, ${postalCode}</p>
        <button onclick="this.parentElement.remove()">🗑</button>
      `;
      addressList.appendChild(item);
      addressForm.reset();
      addressFormContainer.style.display = "none";
      toggleAddressForm.innerHTML = "&#x2b;";
    } else {
      alert(data.message || "Failed to save address.");
    }
  })
  .catch(err => {
    console.error(err);
    alert("Server error while saving address.");
  });
});

// Logout and Delete
document.getElementById("logoutBtn").addEventListener("click", () => {
  window.location.href = "logout.php";
});

document.getElementById("deleteAccountBtn").addEventListener("click", () => {
  const pwd = prompt("Enter password to delete account:");
  if (pwd && confirm("Are you sure? This action is irreversible.")) {
    alert("Account deleted."); // TODO: Add backend logic
  }
});
</script>








<div id="mainContent">
  <!-- Everything in your site except the cart -->



  <section class="main-section hero" aria-label="Hero section" id="hero">

      <!-- Search Bar -->
  <div class="search-bar-container">
    <input type="text" placeholder="Search for products..." class="search-input" />
    <button class="search-button">Search</button>
  </div>
    
    <h1>Confidence in Every Stitch</h1>
    <p>Explore timeless fashion for the modern woman. From everyday wear to elegant statements — find your perfect fit today.</p>
    <button onclick="document.getElementById('all').scrollIntoView({ behavior: 'smooth' });" class="btn" type="button">
  Explore Now
</button>

  </section>


  <!-- Product sections -->


<?php
include 'db.php';

// Fetch New Arrivals and All Products
$newQuery = "SELECT * FROM products WHERE is_new_arrival = 1 ORDER BY product_id DESC";
$allQuery = "SELECT * FROM products WHERE is_new_arrival = 0 ORDER BY product_id DESC";

$newResult = $conn->query($newQuery);
$allResult = $conn->query($allQuery);

$newArrivals = $newResult->fetch_all(MYSQLI_ASSOC);
$others = $allResult->fetch_all(MYSQLI_ASSOC);
?>

<section class="main-section products container my-4" id="new">
  <h2>New Arrivals</h2>
  <div class="product-grid">
    <?php foreach ($newArrivals as $product): ?>
      <div class="product-card">
        <div class="image-stack product-trigger"
          data-name="<?php echo htmlspecialchars($product['name']); ?>"
          data-price="Rs <?php echo number_format($product['price'], 2); ?>"
          data-code="#<?php echo htmlspecialchars($product['product_id']); ?>"
          data-desc="<?php echo htmlspecialchars($product['description']); ?>">
          <?php
            for ($i = 1; $i <= 4; $i++) {
              $imgField = 'image' . $i;
              if (!empty($product[$imgField])) {
                echo '<img src="uploads/' . htmlspecialchars($product[$imgField]) . '" class="' . ($i == 1 ? 'active product-img' : '') . '" />';
              }
            }
          ?>
        </div>
        <h4><?php echo htmlspecialchars($product['name']); ?></h4>
        <p>Rs. <?php echo number_format($product['price'], 2); ?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>



<!-- Discounted sections -->
<?php
include 'db.php';

// Fetch all scheduled/active offers and their products
$query = "
  SELECT 
    o.offer_id, o.offer_name, o.start_date, o.end_date,
    op.old_price, op.new_price,
    p.product_id, p.name AS product_name, p.description AS product_desc,
    p.image1, p.image2, p.image3, p.image4
  FROM offers o
  JOIN offer_products op ON o.offer_id = op.offer_id
  JOIN products p ON op.product_id = p.product_id
  ORDER BY o.offer_id DESC
";

$result = mysqli_query($conn, $query);

// Group products under each offer
$offers = [];
while ($row = mysqli_fetch_assoc($result)) {
    $offerId = $row['offer_id'];
    if (!isset($offers[$offerId])) {
        $offers[$offerId] = [
            'offer_name' => $row['offer_name'],
            'start_date' => $row['start_date'],
            'end_date' => $row['end_date'],
            'products' => []
        ];
    }
    $offers[$offerId]['products'][] = $row;
}
?>

<section class="main-section products container my-4" id="discounted">
  <h2>All Discounted Products</h2>

  <?php if (!empty($offers)): ?>
    <?php foreach ($offers as $offer): ?>
      <div class="offer-block" style="margin-bottom: 30px;">
        <h3 style="color: #e91e63;"><?= htmlspecialchars($offer['offer_name']) ?></h3>
        <p><strong>Scheduled from:</strong> <?= htmlspecialchars($offer['start_date']) ?> 
           <strong>to</strong> <?= htmlspecialchars($offer['end_date']) ?></p>
        <div class="product-grid">
          <?php foreach ($offer['products'] as $product): ?>
            <div class="product-card">
              <div class="image-stack product-trigger"
                data-name="<?= htmlspecialchars($product['product_name']) ?>"
                data-price="Rs <?= number_format($product['new_price'], 2) ?>"
                data-code="#<?= htmlspecialchars($product['product_id']) ?>"
                data-desc="<?= htmlspecialchars($product['product_desc']) ?>">
                
                <?php for ($i = 1; $i <= 4; $i++): 
                  $imgField = 'image' . $i;
                  if (!empty($product[$imgField])): ?>
                    <img src="uploads/<?= htmlspecialchars($product[$imgField]) ?>" class="<?= ($i === 1 ? 'active product-img' : '') ?>" />
                  <?php endif; ?>
                <?php endfor; ?>
              </div>
              <h4><?= htmlspecialchars($product['product_name']) ?></h4>
              <p>
                <del>Rs. <?= number_format($product['old_price'], 2) ?></del> 
                Rs. <?= number_format($product['new_price'], 2) ?>
              </p>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p style="padding: 10px;">No discounted products available at the moment.</p>
  <?php endif; ?>
</section>






<section class="main-section products container my-4" id="all">
  <h2>All Products</h2>
  <div class="product-grid">
    <?php foreach (array_merge($newArrivals, $others) as $product): ?>
      <div class="product-card">
        <div class="image-stack product-trigger"
          data-name="<?php echo htmlspecialchars($product['name']); ?>"
          data-price="Rs <?php echo number_format($product['price'], 2); ?>"
          data-code="#<?php echo htmlspecialchars($product['product_id']); ?>"
          data-desc="<?php echo htmlspecialchars($product['description']); ?>">
          <?php
            for ($i = 1; $i <= 4; $i++) {
              $imgField = 'image' . $i;
              if (!empty($product[$imgField])) {
                echo '<img src="uploads/' . htmlspecialchars($product[$imgField]) . '" class="' . ($i == 1 ? 'active product-img' : '') . '" />';
              }
            }
          ?>
        </div>
        <h4><?php echo htmlspecialchars($product['name']); ?></h4>
        <p>Rs. <?php echo number_format($product['price'], 2); ?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>


<!-- PRODUCT DETAIL MODAL -->
<div class="modal fade" id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productModalLabel">Product Name</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6">
            <!-- Image Carousel -->
            <div id="modalCarousel" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner" id="modalCarouselInner"></div>
              <button class="carousel-control-prev" type="button" data-bs-target="#modalCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#modalCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
              </button>
            </div>
          </div>
          <div class="col-md-6">
            <p><strong>Item Code:</strong> <span id="productCode">#123456</span></p>
            <p><strong>Price:</strong> <span id="productPrice">Rs 5000.00</span></p>
            <p><strong>Description:</strong> <span id="productDesc">Stylish ladies' dress made with premium fabric.</span></p>

            <div class="mb-2">
              <label for="quantity">Quantity:</label>
              <input type="number" id="quantity" class="form-control" value="1" min="1">
            </div>

            <div class="mb-2">
              <label>Size:</label>
              <div>
                <label class="me-2"><input type="radio" name="size" value="S"> S</label>
                <label class="me-2"><input type="radio" name="size" value="M"> M</label>
                <label class="me-2"><input type="radio" name="size" value="XL"> XL</label>
                <label class="me-2"><input type="radio" name="size" value="XXL"> XXL</label>
                <label class="me-2"><input type="radio" name="size" value="XXXL"> XXXL</label>
              </div>
            </div>

            <button class="btn btn-dark mt-2">Add to Cart</button>
          </div>
        </div>

        <!-- Ratings and Reviews -->
        <hr>
        <h6 class="mt-3">Customer Reviews</h6>
        <div>
          <p><strong>Ayesha</strong> ⭐⭐⭐⭐☆</p>
          <p>Comfortable fabric and good fit!</p>
          <hr>
          <p><strong>Shalini</strong> ⭐⭐⭐⭐⭐</p>
          <p>Excellent quality, would buy again.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  // Image hover slide animation
  document.querySelectorAll('.image-stack').forEach(stack => {
    let images = stack.querySelectorAll('img');
    let index = 0;
    let interval;

    stack.addEventListener('mouseenter', () => {
      interval = setInterval(() => {
        images.forEach(img => img.classList.remove('active'));
        index = (index + 1) % images.length;
        images[index].classList.add('active');
      }, 1500);
    });

    stack.addEventListener('mouseleave', () => {
      clearInterval(interval);
      images.forEach(img => img.classList.remove('active'));
      images[0].classList.add('active');
      index = 0;
    });
  });

  // Product Modal Trigger
  document.querySelectorAll('.product-trigger').forEach(trigger => {
    trigger.addEventListener('click', () => {
      const modal = new bootstrap.Modal(document.getElementById('productModal'));

      // Set content dynamically
      document.getElementById('productModalLabel').innerText = trigger.dataset.name;
      document.getElementById('productPrice').innerText = trigger.dataset.price;
      document.getElementById('productCode').innerText = trigger.dataset.code;
      document.getElementById('productDesc').innerText = trigger.dataset.desc;

      const carouselInner = document.getElementById('modalCarouselInner');
      carouselInner.innerHTML = '';

      // Use same images as in image-stack (you can improve this with more specific mapping)
      trigger.querySelectorAll('img').forEach((img, i) => {
        const item = document.createElement('div');
        item.className = 'carousel-item' + (i === 0 ? ' active' : '');
        item.innerHTML = `<img src="${img.src}" class="d-block w-100" style="height: 400px; object-fit: cover; border-radius: 10px;">`;
        carouselInner.appendChild(item);
      });

      modal.show();
    });
  });
</script>






 
  <!-- About Max Fashion -->
  <section class="main-section products" style="background: var(--secondary); text-align: center;">
    <h2>About Max Fashion</h2>
    <p style="max-width: 700px; margin: 0 auto; color: var(--gray); font-size: 1.05rem;">
      Max Fashion is dedicated to empowering women with styles that reflect confidence, grace, and individuality.
      Our collections are designed with love, stitched with care, and tailored to make you feel your best—always.
    </p>
  </section>

  <!-- Contact Us -->
  <<section class="main-section" id="contact">
  <h2 style="text-align:center; margin-bottom:20px">Contact Us</h2>
  <p style="text-align:center; color:var(--gray); margin-bottom:30px">
    Have questions or feedback? We’d love to hear from you!
  </p>

  <form action="submit_contact.php" method="POST" style="text-align: center;">
    <input
      type="text"
      name="name"
      placeholder="Your Name"
      required
      style="width: 100%; max-width: 500px; margin: 10px auto; padding: 10px; display: block;"
    />

    <input
      type="email"
      name="email"
      placeholder="Email Address"
      required
      style="width: 100%; max-width: 500px; margin: 10px auto; padding: 10px; display: block;"
    />

    <textarea
      name="message"
      rows="5"
      placeholder="Your Message"
      required
      style="width: 100%; max-width: 500px; margin: 10px auto; padding: 10px; display: block;"
    ></textarea>

    <button type="submit" class="btn" style="margin-top: 15px;">Send Message</button>
  </form>
</section>


  </div>


  <!-- ✅ CART / ORDER SECTION -->
<section id="cartSection" class="main-section d-none px-5 py-4">
  <div class="d-flex gap-4 border-bottom pb-2 mb-3">
    <div id="tabCart" class="fw-bold cart-tab active" onclick="activateCartTab()">My Cart</div>
    <div id="tabOrders" class="fw-bold cart-tab" onclick="activateOrdersTab()">Order History</div>
  </div>

  <!-- Cart List -->
  <div id="cartList">
    <div class="cart-item d-flex gap-3 mb-4">
      <img src="assets/dress1.webp" class="rounded" style="width: 100px; height: 120px; object-fit: cover;">
      <div class="cart-details flex-grow-1">
        <p class="mb-1"><strong>Item Name</strong></p>
        <p class="mb-1">Size: M</p>
        <p class="mb-1">Price: Rs <span class="item-price">5000</span></p>
        <label>Quantity:</label>
        <input type="number" class="form-control quantity-input w-25" value="1" min="1" onchange="updateCartTotals(this)">
      </div>
      <div class="d-flex flex-column justify-content-between text-end">
        <div class="subtotal">Subtotal: Rs <span class="item-subtotal">5000</span></div>
        <a href="javascript:void(0);" onclick="removeItem(this)" style="color: #dc3545; text-decoration: underline; font-size: 0.9rem;">Remove</a>

      </div>
    </div>

    <div class="text-end mt-4">
      <h4>Total: Rs <span id="cart-total">5000</span></h4>
      <div class="mt-3">
        
        <button class="btn btn-dark" onclick="openCheckoutModal()">Checkout</button>
      </div>
    </div>
  </div>

  <!-- Order History -->
  <div id="orderList" class="d-none">
    <div class="order-item d-flex gap-3 mb-4">
      <img src="assets/dress3.webp" class="rounded" style="width: 100px; height: 120px; object-fit: cover;">
      <div class="order-details flex-grow-1">
        <p class="mb-1"><strong>Past Item</strong></p>
        <p class="mb-1">Size: L | Qty: 2</p>
        <p class="mb-1">Status: <span class="badge bg-success">Delivered</span></p>
      </div>
      <div class="text-end">
        <p>Total: Rs 10000</p>
        <button class="btn btn-outline-danger btn-sm" disabled>Cancel</button>
      </div>
    </div>

    <div class="order-item d-flex gap-3 mb-4">
      <img src="assets/dress4.webp" class="rounded" style="width: 100px; height: 120px; object-fit: cover;">
      <div class="order-details flex-grow-1">
        <p class="mb-1"><strong>Past Item</strong></p>
        <p class="mb-1">Size: XL | Qty: 1</p>
        <p class="mb-1">Status: <span class="badge bg-warning text-dark">Pending</span></p>
      </div>
      <div class="text-end">
        <p>Total: Rs 5000</p>
        <button class="btn btn-danger btn-sm">Cancel Order</button>
      </div>
    </div>
  </div>

</section>

<!-- Updated Checkout Modal -->
<div id="checkoutModal" class="modal-overlay2 d-none" aria-modal="true" role="dialog" aria-labelledby="checkoutTitle">
  <form id="orderForm" enctype="multipart/form-data" method="POST" action="submit_order.php" class="modal-content2 p-4">
    <h3 id="checkoutTitle" class="mb-3">Confirm Your Order</h3>

    <div class="mb-2">
      <label class="form-label fw-semibold">Full Name</label>
      <input type="text" name="customer_name" class="form-control" required>
    </div>

    <div class="mb-2">
      <label class="form-label fw-semibold">Email</label>
      <input type="email" name="customer_email" class="form-control" required>
    </div>

    <div id="checkoutDetails" class="mb-3">
      <p><strong>Total Items:</strong> <span id="totalItemsCount">0</span></p>
      <p><strong>Total Price:</strong> Rs <span id="totalPriceAmount">0</span></p>
    </div>

    <input type="hidden" name="total_items" id="hiddenTotalItems">
    <input type="hidden" name="total_price" id="hiddenTotalPrice">
    <input type="hidden" name="cart_data" id="hiddenCartData">

    <label for="bankSlipUpload" class="form-label fw-semibold">Upload Bank Slip</label>
    <input type="file" name="bank_slip" id="bankSlipUpload" accept="image/*" class="form-control mb-2" required onchange="previewBankSlip(event)" />

    <div id="bankSlipPreview" class="mb-3"></div>

    <div class="alert alert-info" style="font-size: 0.9rem;">
      <strong>Instructions:</strong><br>
      • Only JPG/PNG up to 5MB.<br>
      • Must clearly show transaction details.
    </div>

    <div class="d-flex justify-content-end gap-3 mt-3">
      <button type="button" class="btn btn-secondary" onclick="closeCheckoutModal()">Cancel</button>
      <button type="submit" class="btn btn-primary">Confirm Order</button>
    </div>
  </form>
</div>

<script>
function openCheckoutModal() {
  const cartItems = document.querySelectorAll(".cart-item");
  if (cartItems.length === 0) {
    alert("Cart is empty.");
    return;
  }

  let totalItems = 0, totalPrice = 0;
  let cartData = [];

  cartItems.forEach(item => {
    const name = item.querySelector("strong").innerText;
    const size = item.querySelector("p:nth-child(2)").innerText.split(":")[1].trim();
    const qty = parseInt(item.querySelector(".quantity-input").value);
    const price = parseFloat(item.querySelector(".item-price").innerText);
    totalItems += qty;
    totalPrice += price * qty;

    cartData.push({ name, size, quantity: qty, price });
  });

  document.getElementById("totalItemsCount").innerText = totalItems;
  document.getElementById("totalPriceAmount").innerText = totalPrice.toFixed(2);

  document.getElementById("hiddenTotalItems").value = totalItems;
  document.getElementById("hiddenTotalPrice").value = totalPrice.toFixed(2);
  document.getElementById("hiddenCartData").value = JSON.stringify(cartData);

  document.getElementById("bankSlipPreview").innerHTML = "";
  document.getElementById("bankSlipUpload").value = "";
  document.getElementById("checkoutModal").classList.remove("d-none");
  document.body.style.overflow = "hidden";
}

function closeCheckoutModal() {
  document.getElementById("checkoutModal").classList.add("d-none");
  document.body.style.overflow = "auto";
}

function previewBankSlip(event) {
  const file = event.target.files[0];
  const preview = document.getElementById("bankSlipPreview");
  preview.innerHTML = "";

  if (!file.type.startsWith("image/") || file.size > 5 * 1024 * 1024) {
    alert("Invalid file. Use JPG/PNG under 5MB.");
    event.target.value = "";
    return;
  }

  const reader = new FileReader();
  reader.onload = function(e) {
    preview.innerHTML = `<img src="${e.target.result}" style="max-width: 100%; border-radius: 8px;">`;
  };
  reader.readAsDataURL(file);
}
</script>




   <script>
  function toggleCartSection() {
    const cart = document.getElementById("cartSection");
    const main = document.getElementById("mainContent");
    if (cart.classList.contains("d-none")) {
      cart.classList.remove("d-none");
      main.classList.add("d-none");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      cart.classList.add("d-none");
      main.classList.remove("d-none");
    }
  }

  function showSection(sectionId) {
    document.querySelectorAll(".main-section").forEach(sec =>
      sec.classList.add("d-none")
    );
    document.getElementById(sectionId).classList.remove("d-none");
  }

  function activateCartTab() {
    document.getElementById("tabCart").classList.add("active");
    document.getElementById("tabOrders").classList.remove("active");
    document.getElementById("cartList").classList.remove("d-none");
    document.getElementById("orderList").classList.add("d-none");
  }

  function activateOrdersTab() {
    document.getElementById("tabOrders").classList.add("active");
    document.getElementById("tabCart").classList.remove("active");
    document.getElementById("orderList").classList.remove("d-none");
    document.getElementById("cartList").classList.add("d-none");
  }

  function removeItem(btn) {
    const item = btn.closest(".cart-item");
    item.remove();
    updateCartTotals();
  }

  function updateCartTotals() {
    let total = 0;
    document.querySelectorAll(".cart-item").forEach(item => {
      const price = parseFloat(item.querySelector(".item-price").innerText);
      const qty = parseInt(item.querySelector(".quantity-input").value);
      const subtotal = price * qty;
      item.querySelector(".item-subtotal").innerText = subtotal;
      total += subtotal;
    });
    document.getElementById("cart-total").innerText = total;
  }

  // Click outside the cart to restore full view
document.addEventListener("click", function (event) {
  const cartSection = document.getElementById("cartSection");
  const mainContent = document.getElementById("mainContent");
  const cartIcon = event.target.closest(".bi-cart");
  const bellIcon = event.target.closest(".bi-bell");
  const notificationPanel = event.target.closest('#notificationPanel');

  // Only hide notification panel if click is outside bell and panel
  if (!bellIcon && !notificationPanel) {
    panel.style.display = 'none';
  }

  // Cart restore logic
  if (
    !cartIcon &&
    !bellIcon &&
    !event.target.closest("#cartSection") &&
    !event.target.closest(".cart-btn") && 
    !notificationPanel
  ) {
    if (!mainContent.classList.contains("d-none")) return;
    cartSection.classList.add("d-none");
    mainContent.classList.remove("d-none");
  }
});






function openCheckoutModal() {
    const cartItems = document.querySelectorAll(".cart-item");
    if(cartItems.length === 0) {
      alert("Your cart is empty!");
      return;
    }
    
    // Calculate total items and price
    let totalItems = 0;
    let totalPrice = 0;
    cartItems.forEach(item => {
      const qty = parseInt(item.querySelector(".quantity-input").value);
      const price = parseFloat(item.querySelector(".item-price").innerText);
      totalItems += qty;
      totalPrice += price * qty;
    });

    document.getElementById("totalItemsCount").innerText = totalItems;
    document.getElementById("totalPriceAmount").innerText = totalPrice.toFixed(2);

    // Clear previous upload preview & input
    const bankSlipInput = document.getElementById("bankSlipUpload");
    bankSlipInput.value = "";
    document.getElementById("bankSlipPreview").innerHTML = "";

    // Show modal
    const modal = document.getElementById("checkoutModal");
    modal.classList.remove("d-none");
    document.body.style.overflow = "hidden"; // disable background scroll
  }

  function closeCheckoutModal() {
    const modal = document.getElementById("checkoutModal");
    modal.classList.add("d-none");
    document.body.style.overflow = "auto"; // enable background scroll
  }

  function previewBankSlip(event) {
    const previewContainer = document.getElementById("bankSlipPreview");
    previewContainer.innerHTML = "";
    const file = event.target.files[0];
    if (file) {
      if(!file.type.startsWith('image/')) {
        alert("Please upload a valid image file.");
        event.target.value = "";
        return;
      }
      if(file.size > 5 * 1024 * 1024) { // 5MB limit
        alert("File size exceeds 5MB.");
        event.target.value = "";
        return;
      }
      const img = document.createElement("img");
      img.src = URL.createObjectURL(file);
      previewContainer.appendChild(img);
    }
  }

  function confirmOrder() {
    const bankSlipInput = document.getElementById("bankSlipUpload");
    if(!bankSlipInput.files.length) {
      alert("Please upload your bank slip image before confirming the order.");
      return;
    }

    // Here you can handle the order submission logic (e.g., send data to backend)
    alert("Order confirmed! Thank you for your purchase.");

    // Close modal & optionally reset cart here
    closeCheckoutModal();
  }

  // Your existing cart functions below
  function removeItem(btn) {
    const item = btn.closest(".cart-item");
    item.remove();
    updateCartTotals();
  }

  function updateCartTotals() {
    let total = 0;
    document.querySelectorAll(".cart-item").forEach(item => {
      const price = parseFloat(item.querySelector(".item-price").innerText);
      const qty = parseInt(item.querySelector(".quantity-input").value);
      const subtotal = price * qty;
      item.querySelector(".item-subtotal").innerText = subtotal;
      total += subtotal;
    });
    document.getElementById("cart-total").innerText = total;
  }

  // Cart/Order tab toggles
  function activateCartTab() {
    document.getElementById("tabCart").classList.add("active");
    document.getElementById("tabOrders").classList.remove("active");
    document.getElementById("cartList").classList.remove("d-none");
    document.getElementById("orderList").classList.add("d-none");
  }

  function activateOrdersTab() {
    document.getElementById("tabOrders").classList.add("active");
    document.getElementById("tabCart").classList.remove("active");
    document.getElementById("orderList").classList.remove("d-none");
    document.getElementById("cartList").classList.add("d-none");
  }

</script>


  <footer>
    <p>&copy; 2025 Max Fashion. All rights reserved.</p>
    <p>
      <a href="#">Instagram</a> |
      <a href="#">Facebook</a> |
      <a href="#">Twitter</a>
    </p>
  </footer>

 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

 </div>

 

</body>
</html>

